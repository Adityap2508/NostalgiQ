
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full max-w-5xl text-center mt-10 py-4">
      <p className="text-gray-500 text-sm">
        Powered by Google's VEO Model. Created by a world-class senior frontend React engineer.
      </p>
    </footer>
  );
};
