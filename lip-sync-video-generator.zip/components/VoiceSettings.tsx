import React from 'react';
import { ElevenLabsVoice } from '../types';

interface VoiceSettingsProps {
    elevenLabsApiKey: string;
    onApiKeyChange: (key: string) => void;
    voices: ElevenLabsVoice[];
    selectedVoiceId: string | null;
    onVoiceSelect: (voiceId: string) => void;
    onLoadVoices: () => Promise<void>;
    isLoadingVoices: boolean;
    voiceLoadError: string | null;
}

export const VoiceSettings: React.FC<VoiceSettingsProps> = ({
    elevenLabsApiKey,
    onApiKeyChange,
    voices,
    selectedVoiceId,
    onVoiceSelect,
    onLoadVoices,
    isLoadingVoices,
    voiceLoadError,
}) => {
    return (
        <div className="w-full p-6 bg-gray-800 rounded-2xl shadow-lg flex flex-col">
            <h2 className="text-2xl font-bold text-gray-200 mb-4">3. Voice Settings (Optional)</h2>
            <p className="text-sm text-gray-400 mb-4">
                Use ElevenLabs for a high-quality audio file. You will receive a separate audio file to combine with the video.
            </p>
            <div className="mb-4">
                <label htmlFor="eleven-labs-key" className="block text-sm font-medium text-gray-300 mb-1">
                    ElevenLabs API Key
                </label>
                <input
                    id="eleven-labs-key"
                    type="password"
                    value={elevenLabsApiKey}
                    onChange={(e) => onApiKeyChange(e.target.value)}
                    placeholder="Enter your ElevenLabs API Key"
                    className="w-full p-2 bg-gray-900 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
                    autoComplete="off"
                />
            </div>
            
            <button
                onClick={onLoadVoices}
                disabled={isLoadingVoices || !elevenLabsApiKey}
                className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-purple-500 disabled:bg-gray-700 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center"
            >
                {isLoadingVoices ? (
                    <>
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Loading Voices...
                    </>
                ) : "Load ElevenLabs Voices"}
            </button>
            
            {voiceLoadError && <p className="text-red-400 text-sm mt-2">{voiceLoadError}</p>}
            
            {voices.length > 0 && (
                <div className="mt-4">
                    <label htmlFor="voice-select" className="block text-sm font-medium text-gray-300 mb-1">
                        Select a Voice
                    </label>
                    <select
                        id="voice-select"
                        value={selectedVoiceId || ''}
                        onChange={(e) => onVoiceSelect(e.target.value)}
                        className="w-full p-2 bg-gray-900 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
                    >
                        <option value="" disabled>-- Choose a voice --</option>
                        {voices.map(voice => (
                            <option key={voice.voice_id} value={voice.voice_id}>
                                {voice.name}
                            </option>
                        ))}
                    </select>
                </div>
            )}
        </div>
    );
};