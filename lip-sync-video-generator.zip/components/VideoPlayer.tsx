import React from 'react';

interface VideoPlayerProps {
  videoSrc: string;
  audioSrc: string | null;
  onReset: () => void;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ videoSrc, audioSrc, onReset }) => {
  return (
    <div className="w-full max-w-sm p-6 bg-gray-800 rounded-2xl shadow-lg flex flex-col items-center">
      <h2 className="text-3xl font-bold text-gray-200 mb-4 text-center">Your Video is Ready!</h2>
      
      <div className="w-full mb-6">
        <video
          src={videoSrc}
          controls
          autoPlay
          loop
          className="w-full rounded-lg shadow-inner"
          aria-label="Generated lip-synced video"
        />
        <a 
            href={videoSrc} 
            download="generated-video.mp4"
            className="block w-full text-center mt-3 bg-green-600 text-white font-bold py-2 px-4 rounded-full hover:bg-green-500 transition-colors duration-300"
        >
            Download Video
        </a>
      </div>

      {audioSrc && (
          <div className="w-full mb-6 p-4 bg-gray-900/50 rounded-lg">
              <p className="text-sm text-gray-400 mb-2 text-center">
                  Here is your high-quality ElevenLabs audio. Use a video editor to replace the original audio with this file.
              </p>
              <audio
                src={audioSrc}
                controls
                className="w-full"
                aria-label="Generated high-quality audio"
              />
              <a
                href={audioSrc}
                download="generated-audio.mp3"
                className="block w-full text-center mt-3 bg-purple-600 text-white font-bold py-2 px-4 rounded-full hover:bg-purple-500 transition-colors duration-300"
              >
                  Download Audio
              </a>
          </div>
      )}

      <button
        onClick={onReset}
        className="bg-indigo-600 text-white font-bold py-3 px-6 rounded-full hover:bg-indigo-500 transition-colors duration-300 transform hover:scale-105"
      >
        Create Another
      </button>
    </div>
  );
};