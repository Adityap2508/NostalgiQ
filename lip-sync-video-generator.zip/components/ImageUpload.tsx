import React, { useState, useCallback, useEffect } from 'react';

interface ImageUploadProps {
  onFilesChange: (files: File[]) => void;
  files: File[];
  onImageSelect: (index: number) => void;
  selectedIndex: number | null;
}

export const ImageUpload: React.FC<ImageUploadProps> = ({ onFilesChange, files, onImageSelect, selectedIndex }) => {
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);

  useEffect(() => {
    const newUrls = files.map(file => URL.createObjectURL(file));
    setPreviewUrls(newUrls);

    return () => {
      newUrls.forEach(url => URL.revokeObjectURL(url));
    };
  }, [files]);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const newFiles = event.target.files ? Array.from(event.target.files) : [];
    if (newFiles.length > 0) {
      const allFiles = [...files, ...newFiles].slice(0, 5);
      onFilesChange(allFiles);
    }
    // Reset file input to allow uploading the same file again
    event.target.value = '';
  }, [files, onFilesChange]);

  const handleDrop = useCallback((event: React.DragEvent<HTMLElement>) => {
    event.preventDefault();
    event.stopPropagation();
    const newFiles = event.dataTransfer.files ? Array.from(event.dataTransfer.files) : [];
    if (newFiles.length > 0) {
      const imageFiles = newFiles.filter(file => file.type.startsWith('image/'));
      const allFiles = [...files, ...imageFiles].slice(0, 5);
      onFilesChange(allFiles);
    }
  }, [files, onFilesChange]);

  const handleDragOver = (event: React.DragEvent<HTMLElement>) => {
    event.preventDefault();
    event.stopPropagation();
  };
  
  const handleRemoveAll = () => {
    onFilesChange([]);
  };

  return (
    <div className="w-full p-6 bg-gray-800 rounded-2xl shadow-lg flex flex-col items-center">
      <div className="w-full flex justify-between items-center mb-2">
        <h2 className="text-2xl font-bold text-gray-200">1. Upload Images</h2>
        {files.length > 0 && (
            <button onClick={handleRemoveAll} className="text-sm text-indigo-400 hover:text-indigo-300 transition-colors">
                Clear All
            </button>
        )}
      </div>
      <p className="w-full text-sm text-gray-400 mb-4 text-center">Upload up to 5 images, then select one to be the main subject of the video.</p>
      
      {files.length > 0 ? (
        <div 
            className="w-full grid grid-cols-3 sm:grid-cols-5 gap-3 mb-4 p-2 bg-gray-900/50 rounded-lg"
            onDrop={handleDrop}
            onDragOver={handleDragOver}
        >
            {previewUrls.map((url, index) => (
                <div 
                    key={index} 
                    className={`relative aspect-square rounded-lg cursor-pointer transition-all duration-200 group transform hover:scale-105 ${selectedIndex === index ? 'ring-4 ring-indigo-500 shadow-lg' : 'ring-2 ring-gray-700 hover:ring-indigo-400'}`}
                    onClick={() => onImageSelect(index)}
                    aria-label={`Select image ${index + 1}`}
                >
                    <img src={url} alt={`Preview ${index + 1}`} className="w-full h-full object-cover rounded-md" />
                     {selectedIndex === index && <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center rounded-md"><span className="text-white font-bold text-xs sm:text-sm">Selected</span></div>}
                </div>
            ))}
        </div>
      ) : (
        <label
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          className="w-full h-48 border-4 border-dashed rounded-lg flex flex-col justify-center items-center cursor-pointer transition-colors duration-300 border-gray-600 hover:border-indigo-500 mb-4"
          aria-label="Image drop zone"
        >
          <div className="text-center text-gray-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
            <p className="mt-2">Drag & drop up to 5 images</p>
            <p className="text-sm">or click button below</p>
          </div>
        </label>
      )}

      {files.length < 5 && (
        <>
            <label htmlFor="image-upload" className="w-full bg-gray-700 text-white text-center font-bold py-2 px-4 rounded-full hover:bg-gray-600 cursor-pointer transition-all duration-300">
                {files.length > 0 ? `Add More (${files.length}/5)` : 'Choose Images'}
            </label>
            <input
                id="image-upload"
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleFileChange}
            />
        </>
      )}
    </div>
  );
};