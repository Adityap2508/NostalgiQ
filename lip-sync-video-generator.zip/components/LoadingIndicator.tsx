
import React from 'react';

interface LoadingIndicatorProps {
  title: string;
  message: string;
}

export const LoadingIndicator: React.FC<LoadingIndicatorProps> = ({ title, message }) => {
  return (
    <div className="w-full max-w-md p-8 bg-gray-800 rounded-2xl shadow-lg flex flex-col items-center text-center">
      <div className="w-16 h-16 border-4 border-t-indigo-500 border-gray-600 rounded-full animate-spin mb-6"></div>
      <h3 className="text-2xl font-bold text-gray-200 mb-2">{title}</h3>
      <p className="text-gray-400">{message}</p>
    </div>
  );
};