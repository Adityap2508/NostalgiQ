import React from 'react';

interface ScriptInputProps {
    script: string;
    onScriptChange: (script: string) => void;
}

export const ScriptInput: React.FC<ScriptInputProps> = ({ script, onScriptChange }) => {
    return (
        <div className="w-full p-6 bg-gray-800 rounded-2xl shadow-lg flex flex-col">
            <h2 className="text-2xl font-bold text-gray-200 mb-4">2. Write the Script</h2>
            <textarea
                value={script}
                onChange={(e) => onScriptChange(e.target.value)}
                placeholder="Enter the text you want the image to speak..."
                className="w-full h-48 p-4 bg-gray-900 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-300 text-gray-200 resize-none"
                aria-label="Script input for video"
            />
             <p className="mt-2 text-sm text-gray-500">The script will be used for both video lip-syncing and voice generation.</p>
        </div>
    );
};