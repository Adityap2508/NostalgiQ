import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="w-full max-w-6xl text-center mb-10">
        <div className="inline-block bg-gray-800 p-4 rounded-xl shadow-lg">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500">
                Lip Sync Video Generator
            </h1>
            <p className="mt-2 text-md sm:text-lg text-gray-400">
                Bring your images to life with AI-powered video and voice generation.
            </p>
        </div>
    </header>
  );
};