import { GoogleGenAI } from "@google/genai";

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const result = reader.result as string;
            // Remove the data URL prefix e.g. "data:image/png;base64,"
            resolve(result.split(',')[1]);
        };
        reader.onerror = error => reject(error);
    });
};

export const generateLipSyncedVideo = async (
    imageFile: File,
    script: string,
    onProgressUpdate: (message: string) => void
): Promise<string> => {
    // FIX: API key must be sourced from environment variables, not passed as a parameter.
    if (!process.env.API_KEY) {
        throw new Error("API key is not configured. Please ensure the API_KEY environment variable is set.");
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    try {
        onProgressUpdate("Converting image for the model...");
        const base64Image = await fileToBase64(imageFile);
        
        // FIX: The `speech` property is not valid in `generateVideos` config. The script is now included in the prompt.
        const prompt = `Using the provided image, create a portrait 9:16 video of the person speaking the following script: "${script}". Ensure the lip movements in the video are perfectly synchronized with the generated audio for the script.`;
        
        onProgressUpdate("Sending request to the video model...");
        let operation = await ai.models.generateVideos({
            model: 'veo-2.0-generate-001',
            prompt: prompt,
            image: {
                imageBytes: base64Image,
                mimeType: imageFile.type,
            },
            config: {
                numberOfVideos: 1,
                aspectRatio: '9:16',
            }
        });

        onProgressUpdate("Video generation is in progress. This may take several minutes...");
        
        let checks = 0;
        while (!operation.done) {
            await new Promise(resolve => setTimeout(resolve, 10000)); // Poll every 10 seconds
            checks++;
            onProgressUpdate(`Still processing... (Check ${checks})`);
            operation = await ai.operations.getVideosOperation({ operation: operation });
        }

        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (!downloadLink) {
            throw new Error("Video generation completed, but no download link was found.");
        }

        onProgressUpdate("Downloading generated video...");
        // FIX: API key is sourced from environment variables as per guidelines.
        const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        if (!videoResponse.ok) {
            throw new Error(`Failed to download the video. Status: ${videoResponse.statusText}`);
        }

        const videoBlob = await videoResponse.blob();
        const videoUrl = URL.createObjectURL(videoBlob);

        onProgressUpdate("Video generation successful!");
        return videoUrl;
    } catch (error) {
        console.error("Error in Gemini API call:", error);
        if (error instanceof Error && error.message.includes('API key not valid')) {
             // FIX: The error message for an invalid key should be generic, as the user cannot change it.
            throw new Error("The configured API Key is invalid.");
       }
        throw new Error("Failed to generate video. Please check the console for more details.");
    }
};