import { ElevenLabsVoice } from '../types';

export const loadElevenLabsVoices = async (apiKey: string): Promise<ElevenLabsVoice[]> => {
    if (!apiKey) {
        throw new Error('ElevenLabs API key is required.');
    }
    const response = await fetch('https://api.elevenlabs.io/v1/voices', {
        headers: { 'xi-api-key': apiKey }
    });
    if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        const errorMessage = errorData?.detail?.message || `Failed to load voices. Status: ${response.statusText}`;
        throw new Error(errorMessage);
    }
    const data = await response.json();
    return data.voices;
};

export const generateElevenLabsSpeech = async (
    apiKey: string,
    voiceId: string,
    text: string
): Promise<string> => {
    if (!apiKey || !voiceId || !text) {
        throw new Error('API Key, Voice ID, and text are required to generate speech.');
    }

    // Sanitize text for SSML by escaping special characters.
    const sanitizedText = text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');

    const ssmlText = `<speak><prosody rate="90%">${sanitizedText}</prosody></speak>`;

    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: {
            'Accept': 'audio/mpeg',
            'Content-Type': 'application/json',
            'xi-api-key': apiKey
        },
        body: JSON.stringify({
            text: ssmlText,
            model_id: 'eleven_multilingual_v2', // Use a model that supports SSML
            voice_settings: {
                stability: 0.5,
                similarity_boost: 0.75,
                style: 0.0, // Set to 0 for SSML to have more control
                use_speaker_boost: true
            }
        })
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        const errorMessage = errorData?.detail?.message || `HTTP error! status: ${response.status}`;
        throw new Error(`Failed to generate speech: ${errorMessage}`);
    }

    const audioBlob = await response.blob();
    return URL.createObjectURL(audioBlob);
};
